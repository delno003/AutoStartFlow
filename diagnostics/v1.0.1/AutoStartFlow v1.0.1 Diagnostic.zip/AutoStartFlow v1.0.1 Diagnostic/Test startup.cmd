@echo off
setlocal
set "ASF_DATA_DIR=%TEMP%\AutoStartFlow-startup-check-%RANDOM%-%RANDOM%"
echo AutoStartFlow v1.0.1 diagnostic - close each test window to continue.
echo No installation, settings or exe.xml changes are made by these probes.
echo.
call :probe "%~dp0AutoStartFlow.exe"
call :probe "%~dp0AutoStartFlow Setup.exe"
call :probe "%~dp0runtime\AutoStartFlow.exe"
call :probe "%~dp0runtime\AutoStartFlow Setup.exe"
echo.
echo Logs: %LOCALAPPDATA%\AutoStartFlow\startup.log
echo Also collect startup-native-*.log from that folder.
pause
exit /b 0
:probe
echo Testing %~1
start "" /wait "%~1" --diagnose-startup
set "probe_exit=%errorlevel%"
echo Exit code: %probe_exit%
echo.
exit /b 0
